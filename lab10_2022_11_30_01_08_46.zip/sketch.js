let vid;
let vid2;
let vid3;
function setup() {
  createCanvas(400, 400);
    noCanvas();
   vid = createVideo( ['Untitled Project.mp4'],
    
    vidLoad
  );
  vid2 = createVideo(['cute-kitten-on-white-background-extreme-close-up-meow-SBV-306398815-preview.mp4'],
    vid2Load     
  
  );
  vid3 = createVideo(['wild-alaskan-lynx-walking-through-snow-covered-woods-SBV-300128482-preview.mp4'],
    vid3Load     
  
  );
  vid.size(200, 200);
  vid2.size(200, 200);
  vid3.size(200, 200);
}
  
function vidLoad() {
  vid.loop();
  vid.volume(0);

}
function vid2Load() {
  vid2.loop();
  vid2.volume(0);
}
function vid3Load() {
  vid3.loop();
  vid3.volume(0);
}