var num = 80;
var x = [];
var y = [];
function setup() {
  createCanvas(400, 400);
  for (var i = 0; i < num; i++){
   x[i] = 0;
   y[i] = 0;
  }
}

function draw() {
  var x1 = 10;
  var speed = 20; 
  background('black');
   for (var i = 0; i < num; i++){
   x[i] = x[i-1];
   y[i] = y[i-1];
  }
  x[0] = mouseX;
  y[0] = mouseY;
   if (keyIsPressed === true) {
   noStroke();
  x1 += speed;
  fill('yellow');
  arc(x1, 30, 40, 40, 0.50, 5.60);
  print(x);
  print(y);
 
   
  }else { 
  noStroke();
  x1 += speed;
  fill('yellow');
  ellipse(x1, 30, 40, 40);
  print(x);
  print(y);
  }  
  
}