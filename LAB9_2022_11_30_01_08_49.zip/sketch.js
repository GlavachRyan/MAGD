var mic;
var c;
var amp2
let aud, playing, freq, amp;
var sacle = 1.0;
var sine;
var Play;
var Pause;
let playPressed; 
function setup() {
osc = createCanvas(600, 600);
osc = new p5.Oscillator('sine');
mic = new p5.AudioIn();
  mic.start();
amp = new p5.Amplitude();
  amp.setInput(mic);
  capture = createCapture(VIDEO);
  capture.hide();
  sine = new p5.SinOsc();
  sine.start();
}


function preload() {
  soundFormats('mp3');
  soundTest = loadSound('Recording-_2_.mp3');
  Play = createImg('Start-Button-PNG-File.png'); 
  Pause = createImg('img_30868.png'); 
}


function draw() {
  background(220);
  freq = constrain(map(mouseX, 0, width, 100, 500), 100, 500);
  amp = constrain(map(mouseY, height, 0, 0, 1), 0, 1);

  text(200, 20);
  text(freq, 210, 40);
  text(amp, 220, 60);
if (playing) {
    // smooth the transitions by 0.1 seconds
    osc.freq(freq, 0.1);
    osc.amp(amp, 0.1);
  }
  Play.size(100, 100);
  Play.position(100, 100);
  function mousePressed() {
  if (soundTest.isPlaying()) {
    soundTest.stop();
  } else {
    soundTest.play();
  }

}
function draw2() {
  nostroke(); 
  fill(0, 10);
  rect(0, 0, width, height);
  scale = map(amp.getLevel(), 0, 1.0, 10, width);
  ellipse(width/2, height/2, scale, scale);
}  
function draw3() {
var heartz = map(mouseX, 0, width, 20.0, 440.0);
sine.freq(hertz);
stroke(180);
 for (var x = 0; x < width; x++) {
   var angle = map(x, 0, width, 0, TWO_PI * hertz);
   var sinValue = sin(angle) * 120;
   line(x, 0, x, height/2 + sinValue);
 } 
}  
  function playOscillator() {
  aud.start();
  playing = true;
}

function mouseReleased() {
  osc.amp(0, 0.5);
  playing = false;
}  
  Pause.size(100, 100);
  Pause.position(200, 100);

{
  clicked = false;
}
  image(capture, 0, 0, 100, 100);
  filter(INVERT);
}
